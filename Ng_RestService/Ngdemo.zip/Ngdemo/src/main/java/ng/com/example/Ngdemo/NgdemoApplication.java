package ng.com.example.Ngdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NgdemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(NgdemoApplication.class, args);
	}
}
